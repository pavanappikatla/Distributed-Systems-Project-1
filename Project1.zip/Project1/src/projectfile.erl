%projectfile.erl --- The  file which implements cryptographic hashing and mining bitcoins with matching number of leading zeros.

-module(projectfile).
-export([problem/1,for/2,createinputzeros/2,stringcompare/2]).

%Program to mine coins
for(N,_Inputzerosstring) when N == 0 -> 1; 
for(N,_Inputzerosstring) when N > 0 ->  %Funtion to create coins
  Bytes=9,
  Randomstring = base64:encode(crypto:strong_rand_bytes(Bytes)), %Generates a random alphanumeric string
  UFID = "pappikatla",
  Input = string:concat(UFID,Randomstring),
  Hashedkey = io_lib:format("~64.16.0b", [binary:decode_unsigned(crypto:hash(sha256, Input))]), %Converts string into sha256 format
  Compareflag = stringcompare(string:substr(Hashedkey,1,N),_Inputzerosstring), %Checks if it has the required number of zeroes
  Nextcharacterflag = stringcompare(string:substr(Hashedkey,N+1,1),"0"),
  if Compareflag == 1 ->
    if Nextcharacterflag == 0 ->
      [UFID,Randomstring,"  ",Hashedkey];
    true ->
      for(N,_Inputzerosstring)
    end;
  true ->
    for(N,_Inputzerosstring)
  end.

stringcompare(A,B) when A=:=B -> 1; %Funtion to compare strings
stringcompare(_,_) -> 0.

createinputzeros(N,Zerostring) when N==0 -> Zerostring; %Returns empty string if N is zero
createinputzeros(N,Zerostring) when N > 0 ->  %Function for concating zeroes to Zerostring
  Zerostring1 = string:concat(Zerostring,"0"),
  if N-1 == 0 ->
    Zerostring1;
  true ->
    createinputzeros(N-1,Zerostring1)
  end.

%Main function which invokes this program
problem(N)->
  Zerostring = "",
  for(N,createinputzeros(N,Zerostring)).