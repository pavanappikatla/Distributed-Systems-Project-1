%projectfile.erl --- The  file which implements distributed actor model implementation of bitcoin mining

-module(clientserver).
-export([startmaster/0,startworker/1, ping/4, pong/4,replicateworkers/4]).

%Server Function
ping(_N,Workerpid,0,Counter) -> 
  Scoin = projectfile:problem(_N), %Calling the mining program
  io:format("Server minted a coin ~n ~s mined by ~p~n",[Scoin,node()]), %Printed when server mints a coin
  receive
    {workplease,Workerid} ->
      Workerid ! {ping, work,_N};
    pong ->
      io:format("Server received no message from worker~n", []);  %Message when server doesn't receive a coin from worker
    {pong,Coin,Workerid} ->
      io:format("Server received a coin from worker~n ~s mined by ~p~n",[Coin,Workerid]),  %Message when server receives a coin from worker
      Workerid ! {ping,work,_N}
  end,
ping(_N,Workerpid,0,Counter+1). %Calls server for mining next coin 

%Client Function
pong(_N,Masternode,I,Ncoins) ->  
  receive
    die -> void;  
    finished ->
      io:format("Worker finished~n", []);
    {ping, work, N} ->
      Coin = projectfile:problem(N),  %Worker mining a coin
      io:format("Coin printing started by ~p ~n", [self()]),  %Mined coin is printed
      io:format("Coin data sent to server~n"),  %Coin data is sent to the server
      {serverid,Masternode} ! {pong,Coin,self()}
  end,
  if Ncoins == 2500 ->  %Each client is allowed to print 2500 coins and the recursive calling has been stopped.
    {_, Time1} = statistics(runtime), %Counts runtime of program
    {_, Time2} = statistics(wall_clock),  %Has the clock time of program
    U1 = Time1 * 1000,
    U2 = Time2 * 1000,
    io:format("Code time=~p (~p) microseconds~n", [U1,U2]); %Prints the runtime & clock time of the program
  true ->
    pong(_N,Masternode,I,Ncoins+1)
  end.

replicateworkers(pong,0,I,_Masternode) when I==0 -> io:fwrite("Spawning of all workers completed~n");  %Message that all workers completed mining
replicateworkers(pong,0,I,Masternode) when I>0 -> %Function for replicating workers
  Workerpid = spawn(clientserver, pong, [0,Masternode,I,0]),
  {serverid,Masternode} ! {workplease,Workerpid},
  replicateworkers(pong,0,I-1,Masternode).

%Function to start worker
startworker(Masternode) ->
  replicateworkers(pong,0,50,Masternode). %Starts 50 workers

%Function to start master
startmaster() ->
  statistics(runtime),
  statistics(wall_clock),
  {ok,[N]} = io:fread("Enter the number of leading zeros:","~d"), %Reads input
  Counter = 0,
  register(serverid, spawn(clientserver, ping, [N,node(),0,Counter])),
  io:fwrite("~s~n",[node()]).